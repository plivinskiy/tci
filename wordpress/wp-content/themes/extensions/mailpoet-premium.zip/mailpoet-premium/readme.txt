=== MailPoet 3 - Premium ===
Contributors: mailpoet, wysija
Tags: newsletter, email, welcome email, post notification, autoresponder, mailchimp, signup, smtp
Requires at least: 4.7
Tested up to: 5.1
Requires PHP: 5.6
Stable tag: 3.0.67
Create and send beautiful emails and newsletters from WordPress.

== Description ==

Try the new MailPoet! This is a Premium version of our completely new email newsletter plugin.

= What's new? =

* New email designer
* Responsive templates
* Send with MailPoet's sending service
* Fast user interface
* Easier initial configuration

[Try the demo.](https://demo.mailpoet.com/)

= Check out this 2 minute video. =

[vimeo https://vimeo.com/183339372]

= Use at your own risk! =

Use [the current stable MailPoet](https://wordpress.org/plugins/wysija-newsletters/) instead of this version if you are not a power user.

* This alpha version is for testing purposes only!
* Not RTL compatible
* We expect bug reports from you!
* Multisite not supported
* No migration script from MailPoet 2.X to this version
* Weekly releases

= Premium version =

Not available yet. Limited stats in free version.

= Translations in your language =

We accept translations in the repository.

== Frequently Asked Questions ==

= Need help? =

Our [support site](https://kb.mailpoet.com/) has plenty of articles. You can write to us on the forums too.

== Screenshots ==

1. Sample newsletters.
2. The drag & drop editor.
3. Subscriber management.
4. Sending method configuration in Settings.
5. Importing subscribers with a CSV or from MailChimp.

== Changelog ==

= 3.0.67 - 2019-09-24 =
* Fixed: WooCommerce emails tab now only shows if WooCommerce is active;
* Fixed: incorrect WooCommerce link.

= 3.0.66 - 2019-09-17 =
* Improved: minor changes and fixes.

= 3.0.65 - 2019-09-10 =
* Improved: minor changes and fixes.

= 3.0.64 - 2019-09-04 =
* Improved: logic for displaying MailPoet notices.

= 3.0.63 - 2019-08-27 =
* Improved: better exception catching and handling.

= 3.0.62 - 2019-08-13 =
* Improved: links to our Knowledge Base updated;
* Fixed: fatal error on newsletters stats page if WooCommerce wasn't installed.
* Fixed: scheduled WooCommerce emails to not prevent viewing their stats. Thanks, Dmitris!

= 3.0.61 - 2019-07-30 =
* New: Abandoned cart emails for WooCommerce users, yay!

= 3.0.60 - 2019-07-23 =
* Improved: minor changes and fixes.

= 3.0.59 - 2019-07-09 =
* Improved: minor changes and fixes.

= 3.0.58 - 2019-07-03 =
* Improved: minor changes and fixes.

= 3.0.57 - 2019-07-02 =
* Improved: minor changes and fixes.

= 3.0.56 - 2019-06-25 =
* Improved: minor changes and fixes.

= 3.0.55 - 2019-06-18 =
* Improved: minor changes and fixes.

= 3.0.54 - 2019-06-04 =
* Improved: minor tweaks and fixes.

= 3.0.53 - 2019-05-28 =
* Added: a WooCommerce email to contact the customer when they purchased products in a certain category.

= 3.0.52 - 2019-05-21 =
* Improved: minor changes and fixes.

= 3.0.51 - 2019-05-14 =
* Added: WooCommerce guest checkout customers can now opt-in to email lists, receive WooCommerce emails.

= 3.0.50 - 2019-04-29 =
* Fixed: blank newsletter page for users with PHP 7.0.33.

= 3.0.49 - 2019-04-23 =
* Improved: minor changes and fixes.

= 3.0.48 - 2019-04-16 =
* Improved: minor changes and fixes.

= 3.0.47 - 2019-04-02 =
* Improved: minor changes and fixes.

= 3.0.46 - 2019-03-25 =
* Improved: minor changes and fixes.


= 3.0.45 - 2019-03-11 =
* Improved: minor changes and fixes.

= 3.0.44 - 2019-03-05 =
* Fixed: Welcome email clicked link stats are properly aggregated.

= 3.0.43 - 2019-02-26 =
* Improved: minor changes and fixes.

= 3.0.42 - 2019-02-12 =
* Improved: minor changes and fixes.

= 3.0.41 - 2019-02-05 =
* Improved: minor changes and fixes.

= 3.0.40 - 2019-01-22 =
* Improved: minor changes and fixes.

= 3.0.39 - 2019-01-15 =
* Improved: minor changes and fixes.

= 3.0.38 - 2019-01-08 =
* Fixed: possible conflict with other plugins using webpack. Thanks, Julien;

= 3.0.37 - 2018-12-18 =
* Improved: minor changes and fixes.

= 3.0.36 - 2018-12-13 =
* Improved: minor enhancements.

= 3.0.35 - 2018-12-11 =
* Improved: the stats page is now mobile-friendly;

= 3.0.33 - 2018-12-05 =
* Improved: minor enhancements.

= 3.0.32 - 2018-11-27 =
* Fixed: deleted subscribers are shown as deleted in statistics for clarity.

= 3.0.31 - 2018-11-20 =
* Improved: minor enhancements.

= 3.0.30 - 2018-11-13 =
* Fixed: Dynamic listing segments display trashed entries again;
* Fixed: GA params are added to other subdomains' links. Thanks, Nicole!

= 3.0.29 - 2018-09-11 =
* Improved: minor enhancements.

= 3.0.28 - 2018-10-23 =
* Fixed: trashed segments to not appear in lists filters.

= 3.0.27 - 2018-09-25 =
* Fixed: WooCommerce Purchased This Product emails created and sent for COD and check payments.

= 3.0.26 - 2018-09-11 =
* Improved: minor enhancements.

= 3.0.25 - 2018-09-04 =
* Fixed: automatic first purchase emails for COD and bank transfer payment types restored;

= 3.0.24 - 2018-08-28 =
* Improved: minor enhancements.

= 3.0.23 - 2018-07-17 =
* Improved: we collect more informative data from those who share it with us in order to improve the plugin. You should share too!
* Added: compatibility with the latest MailPoet 3 Free version.

= 3.0.22 - 2018-06-20 =
* Added: feedback badge to gather comments on Automatic Emails;

= 3.0.21 - 2018-06-12 =
* Fixed: statistics are properly displayed for welcome notifications. Thanks, Mike!
* Added: You can now send automatic emails when a customer places their first order or buys a product in your WooCommerce shop;

= 3.0.20 - 2018-05-30 =
* Improved: translation enhancements.

= 3.0.19 - 2018-05-22 =
* Fixed: javascript warnings resolved on Stats page. Thanks Mathieu;
* Fixed: compatibility issue with Members plugin and welcome emails. Thanks Kenneth!

= 3.0.18 - 2018-04-25 =
* Fixed: Fields do not display on last step of email creation.
* Fixed: Welcome email scheduling delay to work again. Thanks Shing and Luc!
* Fixed: Stats showing incorrect results.

= 3.0.17 - 2018-04-10 =
* Improved: subscriber export tool now supports dynamic segments.

= 3.0.16 - 2018-03-20 =
* Updated compatible MailPoet 3 Free version.

= 3.0.15 - 2018-03-13 =
* Improved: plugin usage statistics.

= 3.0.14 - 2018-03-07 =
* Fixed: Welcome Email functionality was restored.

= 3.0.13 - 2018-03-06 =
* Added: bulk actions can now be executed on subscribers belonging to a selected segment.

= 3.0.12 - 2018-02-20 =
* Added: send emails to WooCommerce customers who purchased in a specific product category.

= 3.0.11 - 2018-02-20 =
* Improved: you can now delete segments.

= 3.0.10 - 2018-02-13 =
* Added: segment your subscribers by opened, clicked and unopened events from the stats page of a sent newsletter.

= 3.0.9 - 2018-02-06 =
* Fixed: standard newsletters scheduled for future are sent to dynamic segments. Thanks Amanda;
* Fixed: Premium plugin’s UserRole dynamic segment query works little bit better now, thanks Delta Factory.

= 3.0.8 - 2018-01-30 =
* Fixed: sending emails to WordPress user role segments. Thanks Drew!

= 3.0.7 - 2018-01-23 =
* Fixed: Creation of segments for WP user roles. Thanks Jeff!

= 3.0.6 - 2018-01-16 =
* Improved: made some translations clearer;

= 3.0.5 - 2018-01-02 =
* Improved: you can search segments

= 3.0.4 - 2017-12-12 =
* Improved: you can now segment your subscribers by email events;
* Fixed: pagination in the segment section of the plugin has been fixed;
* Fixed: GA tracking of post notifications works as it should.

= 3.0.3 - 2017-11-14 =
* Improved: you can now view subscribers in dynamic segments.

= 3.0.2 - 2017-11-07 =
* Added: early preview of dynamic subscriber segmentation based on WP user roles. Let us know your feedback!

= 3.0.1 - 2017-10-24 =
* Fixed: we localized numbers across our entire UI for readability

= 3.0.0 - 2017-09-20 =
* Official launch of the new MailPoet. :)

= 3.0.0-rc.2.0.1 - 2017-09-12 =
* Fixed: translations are properly loaded;

= 3.0.0-rc.2.0.0 - 2017-08-29 =
* Improved: error messages when plugin needs to be updated;

= 3.0.0-rc.1.0.2 - 2017-08-22 =
* Fixed: unopened subscribers tally in statistics is now correct. Thanks Sophie and Eugene!

= 3.0.0-rc.1.0.1 - 2017-08-15 =
* Fixed: translations should now be up to date;

= 3.0.0-rc.1.0.0 - 2017-08-01 =
* Improved: MailPoet 3 is no longer in Beta!

= 3.0.0-beta.4.0.0 - 2017-07-25 =
* Improved: we collect more informative data from those who share it with us in order to improve the plugin. You should share too!
* Fixed: sending newsletters with GA campaigns works again.

= 3.0.0-beta.3.0.1 - 2017-06-23 =
* Fixed: administrator pages will not display error notices.

= 3.0.0-beta.3.0.0 - 2017-06-20 =
* Fixed: settings page is not blocked any more if you have more than 2000 subscribers which prevented Premium version updates;
* Improved: newsletter stats are zippier on large data sets.

= 3.0.0-beta.2.0.0 - 2017-06-13 =
* Fixed: plugins that change WP upload directory will not interfere with MailPoet Premium caching.

= 3.0.0-beta.1.0.0 - 2017-06-07 =
* Premium is now in the beta phase!;
* Added: updates for Premium will show up in your admin;
* Improved: stats page UX got a little better.

= 3.0.0-alpha.0.1 - 2017-05-31 =
* Added: plugin can now be translated into different languages. If you would like to help us translate MailPoet 3 Premium into your language, please visit our Transifex page (https://www.transifex.com/wysija/mp3-pro);
* Fixed: plugin reinstallation via Settings page to work with new versions of MailPoet 3;
* Fixed: error will be correctly displayed when the plugin is missing core files;
* Changed: minimum PHP version requirement from 5.3 to 5.3.3.

= 3.0.0-alpha.0.0.4 - 2017-05-23 =
* Fixed: Premium behavior to work with new versions of MailPoet 3.

= 3.0.0-alpha.0.0.3 - 2017-04-26 =
* Added: detailed statistics for single campaigns are now available.

= 3.0.0-alpha.0.0.2 - 2017-03-23 =
* Added: 2000 subscriber limit is unlocked;
* Added: links can be tracked with Google Analytics in sent emails.

= 3.0.0-alpha.0.0.1 - 2016-12-13 =
* Initial plugin structure.
