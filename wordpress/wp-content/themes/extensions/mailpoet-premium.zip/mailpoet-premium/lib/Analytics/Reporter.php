<?php
namespace MailPoet\Premium\Analytics;

if (!defined('ABSPATH')) exit;


use MailPoet\Models\Newsletter;
use MailPoet\Premium\AutomaticEmails\WooCommerce\Events\AbandonedCart;
use MailPoet\Premium\AutomaticEmails\WooCommerce\Events\FirstPurchase;
use MailPoet\Premium\AutomaticEmails\WooCommerce\Events\PurchasedInCategory;
use MailPoet\Premium\AutomaticEmails\WooCommerce\Events\PurchasedProduct;

class Reporter {

  function getData() {
    $first_purchase_emails = Newsletter::getPublished()
      ->filter('filterType', Newsletter::TYPE_AUTOMATIC, FirstPurchase::SLUG)
      ->filter('filterStatus', Newsletter::STATUS_ACTIVE)
      ->count();

    $purchased_product_emails = Newsletter::getPublished()
      ->filter('filterType', Newsletter::TYPE_AUTOMATIC, PurchasedProduct::SLUG)
      ->filter('filterStatus', Newsletter::STATUS_ACTIVE)
      ->count();

    $purchased_category_emails = Newsletter::getPublished()
      ->filter('filterType', Newsletter::TYPE_AUTOMATIC, PurchasedInCategory::SLUG)
      ->filter('filterStatus', Newsletter::STATUS_ACTIVE)
      ->count();

    $abandoned_cart_emails = Newsletter::getPublished()
      ->filter('filterType', Newsletter::TYPE_AUTOMATIC, AbandonedCart::SLUG)
      ->filter('filterStatus', Newsletter::STATUS_ACTIVE)
      ->count();

    return [
      'Number of active WooCommerce First Purchase emails' => $first_purchase_emails,
      'Number of active WooCommerce Purchased This Product emails' => $purchased_product_emails,
      'Number of active purchased in this category' => $purchased_category_emails,
      'Number of active abandoned cart' => $abandoned_cart_emails,
    ];
  }

}
