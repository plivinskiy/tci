<?php

namespace MailPoet\Premium\DynamicSegments\Exceptions;

if (!defined('ABSPATH')) exit;



class ErrorSavingException extends \Exception {

}