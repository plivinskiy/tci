<?php

namespace MailPoet\Premium\DI;

if (!defined('ABSPATH')) exit;


use MailPoet\DI\IContainerConfigurator;
use MailPoetVendor\Symfony\Component\DependencyInjection\ContainerBuilder;
use MailPoetVendor\Symfony\Component\DependencyInjection\Reference;

class ContainerConfigurator implements IContainerConfigurator {

  function getDumpNamespace() {
    return 'MailPoetGenerated';
  }

  function getDumpClassname() {
    return 'PremiumCachedContainer';
  }

  function configure(ContainerBuilder $container) {
    // Every service must be registered
    // Strict mode disables magical loading services by looking for an instance within other services
    // see https://symfonycasts.com/screencast/symfony4-upgrade/service-deprecations#strict-autowiring-mode
    $container->setParameter('container.autowiring.strict_mode', true);

    // Factory for free deps
    $container->register(IContainerConfigurator::FREE_CONTAINER_SERVICE_SLUG)
      ->setSynthetic(true)
      ->setPublic(true);

    // Free plugin dependencies
    $this->registerFreeService($container, \MailPoet\AdminPages\PageRenderer::class);
    $this->registerFreeService($container, \MailPoet\Config\AccessControl::class);
    $this->registerFreeService($container, \MailPoet\Config\Menu::class);
    $this->registerFreeService($container, \MailPoet\Config\Renderer::class);
    $this->registerFreeService($container, \MailPoet\Features\FeaturesController::class);
    $this->registerFreeService($container, \MailPoet\Listing\BulkActionController::class);
    $this->registerFreeService($container, \MailPoet\Listing\Handler::class);
    $this->registerFreeService($container, \MailPoet\Listing\PageLimit::class);
    $this->registerFreeService($container, \MailPoet\WooCommerce\Helper::class);
    $this->registerFreeService($container, \MailPoet\Settings\SettingsController::class);
    $this->registerFreeService($container, \MailPoet\WP\Functions::class);
    $this->registerFreeService($container, \MailPoet\Referrals\ReferralDetector::class);
    $this->registerFreeService($container, \MailPoet\WooCommerce\TransactionalEmails::class);

    // API
    $container->autowire(\MailPoet\Premium\API\JSON\v1\AutomaticEmails::class)->setPublic(true);
    $container->autowire(\MailPoet\Premium\API\JSON\v1\DynamicSegments::class)->setPublic(true);
    $container->autowire(\MailPoet\Premium\API\JSON\v1\NewsletterLinks::class)->setPublic(true);
    $container->autowire(\MailPoet\Premium\API\JSON\v1\Stats::class)->setPublic(true);
    // AutomaticEmails
    $container->autowire(\MailPoet\Premium\AutomaticEmails\WooCommerce\Helper::class);
    // Config
    $container->autowire(\MailPoet\Premium\Config\Hooks::class);
    $container->autowire(\MailPoet\Premium\Config\Initializer::class)->setPublic(true);
    $container->autowire(\MailPoet\Premium\Config\Activator::class)->setPublic(true);
    $container->autowire(\MailPoet\Premium\Config\Populator::class);
    $container->autowire(\MailPoet\Premium\Config\Menu::class)->setPublic(true);
    $container->register(\MailPoet\Premium\Config\Renderer::class)
      ->setPublic(true)
      ->setFactory([__CLASS__, 'createRenderer']);
    // Stats
    $container->autowire(\MailPoet\Premium\Newsletter\Stats\PurchasedProducts::class);
    return $container;
  }

  private function registerFreeService(ContainerBuilder $container, $id) {
    $container->register($id)
      ->setPublic(true)
      ->addArgument($id)
      ->setFactory([
        new Reference(IContainerConfigurator::FREE_CONTAINER_SERVICE_SLUG),
        'get',
      ]);
  }

  static function createRenderer() {
    $caching = !WP_DEBUG;
    $debugging = WP_DEBUG;
    return new \MailPoet\Premium\Config\Renderer($caching, $debugging);
  }
}
