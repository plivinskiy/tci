<?php

namespace MailPoet\Premium\Newsletter\Stats;

if (!defined('ABSPATH')) exit;


use MailPoet\Models\StatisticsWooCommercePurchases;
use MailPoet\WooCommerce\Helper as WCHelper;
use MailPoet\WP\Functions as WPFunctions;

class PurchasedProducts {

  /** @var WCHelper */
  private $woocommerce_helper;

  /** @var WPFunctions */
  private $wp;

  public function __construct(
    WCHelper $woocommerce_helper,
    WPFunctions $wp
  ) {
    $this->woocommerce_helper = $woocommerce_helper;
    $this->wp = $wp;
  }

  function getStats($newsletter_id) {
    if (!$newsletter_id || !$this->woocommerce_helper->isWooCommerceActive()) {
      return [];
    }

    $currency = $this->woocommerce_helper->getWoocommerceCurrency();
    $purchases = StatisticsWooCommercePurchases
      ::where('newsletter_id', $newsletter_id)
      ->where('order_currency', $currency)
      ->findMany();
    $result = $this->getStatsForPurchases($purchases);
    $result = $this->formatPrices($result, $currency);
    $result = $this->addThumbnails($result);
    $result = $this->sortProducts($result);
    return $result;
  }

  private function getStatsForPurchases($purchases) {
    $result = [];
    foreach ($purchases as $purchase) {
      foreach ($this->getOrderItems($purchase) as $order_item) {
        $product_id = $order_item->get_product_id();
        if (!isset($result[$product_id])) {
          $result[$product_id] = [
            'name' => $order_item->get_name(),
            'count' => $order_item->get_quantity(),
            'total' => (float)$order_item->get_total(),
            'product_id' => $product_id,
          ];
        } else {
          $result[$product_id]['count'] += $order_item->get_quantity();
          $result[$product_id]['total'] += (float)$order_item->get_total();
        }
      }
    }
    return $result;
  }

  /**
   * @return \WC_Order_Item_Product[]
   */
  private function getOrderItems(StatisticsWooCommercePurchases $purchase) {
    $order = $this->woocommerce_helper->wcGetOrder($purchase->order_id);
    if (!$order) {
      return [];
    }
    // get_items returns by default only product items, no shipping or coupons or anything
    return $order->get_items();
  }

  private function formatPrices($products, $currency) {
    $result = [];
    foreach ($products as $product_id => $product) {
      $product['formatted_total'] = $this->woocommerce_helper->getRawPrice($product['total'], ['currency' => $currency]);
      $result[$product_id] = $product;
    }
    return $result;
  }

  private function addThumbnails($products) {
    $result = [];
    foreach ($products as $product_id => $product) {
      $image = $this->getProductImage($product_id);
      if (is_array($image)) {
        list($src) = $image;
        $product['image_url'] = $src;
      }
      $result[$product_id] = $product;
    }
    return $result;
  }

  private function getProductImage($product_id) {
    $woo_product = $this->woocommerce_helper->wcGetProduct($product_id);
    if (!$woo_product) {
      return false;
    }
    return $this->wp->wpGetAttachmentImageSrc($woo_product->get_image_id());
  }

  private function sortProducts($products) {
    usort($products, function($a, $b) {
      $retval = $b['count'] - $a['count'];
      if ($retval === 0) {
        $retval = $b['total'] - $a['total'];
      }
      return $retval;
    });
    return $products;
  }

}
