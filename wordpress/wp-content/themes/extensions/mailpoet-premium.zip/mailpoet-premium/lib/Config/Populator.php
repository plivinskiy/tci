<?php

namespace MailPoet\Premium\Config;

if (!defined('ABSPATH')) exit;


use MailPoet\Config\Env as ParentEnv;
use MailPoet\Features\FeaturesController;
use MailPoet\Models\Newsletter;
use MailPoet\Referrals\ReferralDetector;
use MailPoet\Settings\SettingsController;
use MailPoet\Subscription\Captcha;
use MailPoet\WP\Functions as WPFunctions;
use MailPoet\WooCommerce\TransactionalEmails;

class Populator extends \MailPoet\Config\Populator {
  function __construct(
    WPFunctions $wp,
    SettingsController $settings,
    ReferralDetector $referral_detector,
    FeaturesController $features_controller,
    TransactionalEmails $wc_transactional_emails
  ) {
    parent::__construct($settings, $wp, new Captcha, $referral_detector, $features_controller, $wc_transactional_emails);
    $this->prefix = ParentEnv::$db_prefix;
    $this->models = [
      'newsletter_option_fields',
    ];
    $this->templates = [];
  }

  function up() {
    array_map([$this, 'populate'], $this->models);
  }

  protected function newsletterOptionFields() {
    $fields = [
      'group',
      'event',
      'sendTo',
      'segment',
      'afterTimeNumber',
      'afterTimeType',
      'meta',
    ];

    return [
      'rows' => array_map(function($field) {
        return [
          'name' => $field,
          'newsletter_type' => Newsletter::TYPE_AUTOMATIC,
        ];
      }, $fields),
      'identification_columns' => [
        'name',
        'newsletter_type',
      ],
    ];
  }
}
