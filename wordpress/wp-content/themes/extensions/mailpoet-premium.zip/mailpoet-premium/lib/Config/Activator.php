<?php

namespace MailPoet\Premium\Config;

if (!defined('ABSPATH')) exit;


use MailPoet\Settings\SettingsController;

class Activator {

  /** @var Populator */
  private $populator;

  public function __construct(Populator $populator) {
    $this->populator = $populator;
  }

  function activate() {
    $migrator = new Migrator;
    $migrator->up();

    $this->populator->up();

    self::updateDbVersion();
  }

  private function deactivate() {
    $migrator = new Migrator;
    $migrator->down();
  }

  function reset() {
    $this->deactivate();
    $this->activate();
  }

  function updateDbVersion() {
    $settings = new SettingsController();

    try {
      $current_db_version = $settings->get('premium_db_version');
    } catch (\Exception $e) {
      $current_db_version = null;
    }

    $settings->set('premium_db_version', Env::$version);

    // if current db version and plugin version differ, log an update
    if (version_compare($current_db_version, Env::$version) !== 0) {
      $updates_log = (array)$settings->get('premium_updates_log', []);
      $updates_log[] = [
        'previous_version' => $current_db_version,
        'new_version' => Env::$version,
        'date' => date('Y-m-d H:i:s'),
      ];
      $settings->set('premium_updates_log', $updates_log);
    }
  }
}
