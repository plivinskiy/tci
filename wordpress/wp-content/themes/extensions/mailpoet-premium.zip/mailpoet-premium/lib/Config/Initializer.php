<?php

namespace MailPoet\Premium\Config;

if (!defined('ABSPATH')) exit;


use MailPoet\Cron\Workers\StatsNotifications\Worker;
use MailPoet\DI\ContainerWrapper;
use MailPoet\Premium\DynamicSegments\SegmentStringsFilter;
use MailPoet\Premium\Models\NewsletterExtraData;
use MailPoet\Premium\AutomaticEmails\AutomaticEmails as AutomaticEmails;
use MailPoet\Premium\Newsletter\GATracking;
use MailPoet\WP\Functions as WPFunctions;
use MailPoet\Settings\SettingsController;
use MailPoet\Premium\Config\Hooks as ConfigHooks;

class Initializer {
  /** @var Menu */
  private $menu;
  public $automatic_emails;

  private $renderer;

  /** @var WPFunctions */
  private $wp;

  /** @var ConfigHooks */
  private $hooks;

  /** @var SettingsController */
  private $settings;

  function __construct(WPFunctions $wp, ConfigHooks $hooks, SettingsController $settings) {
    $this->wp = $wp;
    $this->hooks = $hooks;
    $this->settings = $settings;
  }

  function init($params = [
    'file' => '',
    'version' => '1.0.0',
  ]) {
    Env::init($params['file'], $params['version']);
    WPFunctions::get()->registerActivationHook(
      Env::$file,
      [$this, 'runActivator']
    );

    $this->wp->addAction('mailpoet_initialized', [
      $this,
      'setup',
    ]);
  }

  function setup() {
    $this->setupLocalizer();
    $this->setupDB();
    $this->maybeDbUpdate();
    $this->setupRenderer();
    $this->setupMenu();

    $this->wp->addAction(
      'mailpoet_styles_admin_after',
      [$this, 'includePremiumStyles']
    );

    $this->wp->addAction(
      'mailpoet_scripts_admin_before',
      [$this, 'includePremiumJavascript']
    );

    $this->setupNewsletterExtraData();
    $this->setupGATracking();
    $this->setupCampaignStats();
    $this->setupAutomaticEmails();

    $this->wp->addAction(
      'mailpoet_setup_reset',
      [$this, 'setupReset']
    );

     $this->hooks->init();
  }

  function runActivator() {
    $container = ContainerWrapper::getInstance(WP_DEBUG)->getPremiumContainer();
    $activator = $container->get(Activator::class);
    $activator->activate();
  }

  function setupReset() {
    $container = ContainerWrapper::getInstance(WP_DEBUG)->getPremiumContainer();
    $activator = $container->get(Activator::class);
    $activator->reset();
  }

  function maybeDbUpdate() {
    try {
      $container = ContainerWrapper::getInstance(WP_DEBUG)->getPremiumContainer();
      $current_db_version = $container->get(SettingsController::class)->get('premium_db_version');
    } catch (\Exception $e) {
      $current_db_version = null;
    }

    // if current db version and plugin version differ
    if (version_compare($current_db_version, Env::$version) !== 0) {
      $this->runActivator();
    }
  }

  function setupDB() {
    $database = new Database();
    $database->init();
  }

  function setupRenderer() {
    $container = ContainerWrapper::getInstance(WP_DEBUG)->getPremiumContainer();
    $this->renderer = $container->get(Renderer::class);
  }

  function setupLocalizer() {
    $localizer = new Localizer();
    $localizer->init();
  }

  function setupMenu() {
    $container = ContainerWrapper::getInstance(WP_DEBUG)->getPremiumContainer();
    $this->menu = $container->get(Menu::class);
    assert($this->menu instanceof Menu); // for PHPStan
    $this->wp->addAction(
      'mailpoet_menu_after_lists',
      [$this->menu, 'afterLists']
    );
  }

  function setupAutomaticEmails() {
    $automatic_emails = new AutomaticEmails();
    $automatic_emails->init();
    $this->automatic_emails = $automatic_emails->getAutomaticEmails();

    $this->wp->addAction(
      'mailpoet_newsletters_translations_after',
      [$this, 'includeAutomaticEmailsData']
    );

    $this->wp->addAction(
      'mailpoet_newsletter_editor_after_javascript',
      [$this, 'includeAutomaticEmailsData']
    );
  }

  function setupNewsletterExtraData() {
    NewsletterExtraData::init();
  }

  function setupGATracking() {
    GATracking::init();

    $this->wp->addAction(
      'mailpoet_newsletters_translations_after',
      [$this, 'newslettersGATracking']
    );
  }

  function setupCampaignStats() {
    $this->wp->addAction(
      'mailpoet_newsletters_translations_after',
      [$this, 'newslettersCampaignStats']
    );
  }

  function newslettersGATracking() {
    echo $this->renderer->render('newsletters/ga_tracking.html');
  }

  function newslettersCampaignStats() {
    // shortcode URLs to substitute with user-friendly names
    $data['shortcode_links'] = Worker::getShortcodeLinksMapping();

    echo $this->renderer->render('newsletters/campaign_stats.html', $data);
  }

  function includePremiumStyles() {
    echo $this->renderer->render('styles.html');
  }

  function includePremiumJavascript() {
    echo $this->renderer->render('scripts.html');
  }

  function includeAutomaticEmailsData() {
    $data = [
      'automatic_emails' => $this->automatic_emails,
      'woocommerce_optin_on_checkout' => $this->settings->get('woocommerce.optin_on_checkout.enabled', false),
    ];

    echo $this->renderer->render('newsletters/automatic_emails.html', $data);
  }
}
