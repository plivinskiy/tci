=== Woo Checkout Editor ===
Contributors: Themeco
Tags: woo-checkout-editor
Requires at least: 4.9.0
Tested up to: 5.2
Requires PHP: 5.2

Easily update your WooCommerce checkout page to suit your needs by adding or removing extra fields as needed with the click of a button.

== Description ==

Woo Checkout Editor is a simple and easy to use WooCommerce Extension that allows you to modify, edit, and remove fields from the WooCommerce checkout process. Allow customers to upload files, or add a new text area for your customers to enter any information you want.

== Changelog ==

= 2.2.1 =
*Release Date: September 23, 2019*

* Bugfix: Fix single quote appearing in select field.
* Bugfix: Fix state still required even if country doesn't have any state.
* Bugfix: Fix options button not popping up.
* Bugfix: Fix field sorting not working.
* Bugfix: Clean PHP notices mistakenly being saved into fields.
* Bugfix: Fix field condition settings hiding current field instead of the target field.
* Bugfix: Fix JS error when removing the last option of the Cart Contains and Cart Not Contains multiselect.
* Bugfix: Fix Cart Contains and Cart Not Contains multiselect options not added back if it's removed in the other condition.

= 2.2.0 =
*Release Date: October 11, 2018*

* Update: Add field validation

= 2.0.1 =
*Release Date: October 18, 2017*

* Bugfix: Fix warnings for unset variables
* Bugfix: Fix custom fields not being displayed on Order Details

= 2.0.0 =
*Release Date: July 19, 2017*

* Feature: Standalone version. Now works with or without X.
* Bugfix: Fix Woo Checkout Editor file upload.
* Bugfix: Allow custom field to be deleted on Woo Checkout Manager.
* Bugfix: Fix required fields error on Woo Checkout Editor.

= 1.0.0 =
*Release Date: April 10, 2017*

* Feature: Initial Release
