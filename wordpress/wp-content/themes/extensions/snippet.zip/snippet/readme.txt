=== Snippet ===
Contributors: Themeco
Tags: snippets
Requires at least: 4.9.0
Tested up to: 5.2
Requires PHP: 5.2
 
Add Schema.Org for SEO improvement.
 
== Description ==
 
Snippet is the easiest to use structured data tool available for WordPress. Add your business, organization, or company details in minutes. Snippet allows you to harness the power of Schema, ranking you up in searches and making it easier for people to find your site.
  
== Changelog ==

= 2.1.0 =
*Release Date: September 23, 2019*

* Update: Add filters to allow programatically altering JSON LD output.
* Bugfix: Remove warning in the switch statement in PHP 7.3.
* Update: Review rating now use input type number instead of radio buttons to support ratings with decimal values.
* Update: Added error trapping for review rating. Rating can't go beyond the best rating and below the worst rating.

= 2.0.2 =
*Release Date: July 26, 2017*

* Bugfix: Fix admin assets not loading.

= 2.0.1 =
*Release Date: July 20, 2017*

* Update: Adjust validation for images and Article.
* Update: Return dashboard menu item to be under X/Pro instead of settings.

= 2.0.0 =
*Release Date: July 19, 2017*

* Feature: Standalone version. Now works with or without X.
* Bugfix: Add language column header to Add Contact on Snippet.
* Bugfix: Add Tco prefix to Snippet to avoid conflicts with Code snippet plugin.
* Bugfix: Fix snippets validation errors.
* Bugfix: Fix Snippet styles on post type editing.

= 1.0.0 =
*Release Date: April 10, 2017*

* Feature: Initial release.
