=== Facebook Comments ===
Contributors: Themeco
Tags: facebook, comments
Requires at least: 4.9.0
Tested up to: 5.2
Requires PHP: 5.2
 
Simply create a Facebook Developer app, adjust your settings, and activate the plugin. Social commenting made easy by your friends at Themeco.
 
== Description ==
 
Take advantage of powerful and unique features by integrating Facebook comments on your website instead of the standard WordPress commenting system.

== Changelog ==

= 2.0.4 =
*Release Date: September 23, 2019*

* Bugfix: Fix script tag output in <head> instead of <body>.
* Bugfix: Fix script not loading correct localization.

= 2.0.3 =
*Release Date: October 18, 2017*

* Bugfix: Fix array error on PHP < 5.6 while installing

= 2.0.2 =
*Release Date: July 26, 2017*

* Bugfix: Fix admin assets not loading.

= 2.0.1 =
*Release Date: July 20, 2017*

* Update: Return dashboard menu item to be under X/Pro instead of settings.

= 2.0.0 =
*Release Date: July 19, 2017*

* Feature: Standalone version. Now works with or without X.
* Bugfix: Fix Facebook comments not displaying.

= 1.0.1 =
*Release Date: January 22, 2016*

* Update: Added support for mobile comments.

= 1.0.0 =
*Release Date: November 12, 2014*

* Feature: Initial Release