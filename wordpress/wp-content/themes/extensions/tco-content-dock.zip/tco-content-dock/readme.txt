=== Content Dock ===
Contributors: Themeco
Tags: content-docks
Requires at least: 4.9.0
Tested up to: 5.2
Requires PHP: 5.2

An incredibly simple and effective tool that allows you to place content or marketing offers in an elegant, non-intrusive manner.
 
== Description ==
 
An incredibly simple and effective tool that allows you to place content or marketing offers in front of your users in an elegant, non-intrusive manner.
  
== Changelog ==

= 2.0.4 =
*Release Date: September 23, 2019*

* Bugfix: Fix inability to change link color
* Bugfix: Fix style and script not rendering on index page
* Feature: Add x-portfolios support.

= 2.0.3 =
*Release Date: October 18, 2017*

* Update: Adjust disable border color
* Update: All pages include home page
* Bugfix: Fix array error on PHP < 5.6 while installing
* Bugfix: Fix Content Dock scripts not loading in Pro
* Bugfix: Fix close button emoji override
* Bugfix: Fix Content Dock not displaying on WooCommerce pages
* Bugfix: Fix Content Dock issue on "Use an override image and URL" check box

= 2.0.2 =
*Release Date: July 26, 2017*

* Bugfix: Fix admin assets not loading.

= 2.0.1 =
*Release Date: July 20, 2017*

* Update: Return dashboard menu item to be under X/Pro instead of settings.

= 2.0.0 =
*Release Date: July 19, 2017*

* Feature: Standalone version. Now works with or without X.

= 1.1.0 =
*Release Date: December 12, 2016*

* Feature: Allow display after "n" seconds even without scrolling to the bottom.
* Feature: Add to all posts/pages/woocommerce products.
* Feature: Implement "Do not show again" using cookie.
* Feature: Add woocomerce products support.
* Feature: Allow an override image/url link.

= 1.0.0 =
*Release Date: November 12, 2014*

* Feature: Initial Release
